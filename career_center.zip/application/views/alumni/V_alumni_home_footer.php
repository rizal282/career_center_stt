    <script>
        jQuery(document).ready(function() {
            Main.init();
            //Login.init();
            TableData.init();
        });
    </script>

</body>
</html>