        <!-- start: FOOTER -->
        <div class="footer clearfix">
            <div class="footer-inner">
                <script>
                    document.write(new Date().getFullYear())
                </script> &copy; clip-one by cliptheme.
            </div>
            <div class="footer-items">
                <span class="go-top"><i class="clip-chevron-up"></i></span>
            </div>
        </div>
        <!-- end: FOOTER -->
        <!-- start: COPYRIGHT -->
        <div class="copyright">
            <script>
                document.write(new Date().getFullYear())
            </script> &copy; clip-one by cliptheme.
        </div>
        <!-- end: COPYRIGHT -->
    </div>

    <!-- start: MAIN JAVASCRIPTS -->
    <!--[if lt IE 9]>
            <script src=".<?php echo base_url(); ?>lib_career_center/adm_career_center/bower_components/respond/dest/respond.min.js"></script>
            <script src="<?php echo base_url(); ?>lib_career_center/adm_career_center/bower_components/Flot/excanvas.min.js"></script>
            <script src="<?php echo base_url(); ?>lib_career_center/adm_career_center/bower_components/jquery-1.x/dist/jquery.min.js"></script>
            <![endif]-->
    <!--[if gte IE 9]><!-->
    

    <script>
        jQuery(document).ready(function() {
            Main.init();
            Login.init();
            TableData.init();
        });
    </script>

</body>

</html>